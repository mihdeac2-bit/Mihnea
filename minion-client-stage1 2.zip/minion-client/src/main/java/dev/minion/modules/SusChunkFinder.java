package dev.minion.modules;

import dev.minion.core.Category;
import dev.minion.core.Module;
import dev.minion.core.setting.BoolSetting;
import dev.minion.core.setting.NumberSetting;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.text.Text;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.ChunkStatus;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Map;

/**
 * Stage 1: scanning, chat notifications and a particle pillar over each geode (a solid beam / chunk fill
 * needs the custom 1.21.11 render pipeline, which arrives with the rendering stage). Budding amethyst never exists as an item, so any budding block is a
 * directly observed natural geode block. Many amethyst blocks without budding is a weaker signal.
 */
public class SusChunkFinder extends Module {
    public record Hit(int minX, int minY, int minZ, int maxX, int maxY, int maxZ, int budding, int blocks) {}

    public final NumberSetting minBlocks = add(new NumberSetting("Min amethyst blocks",
            "Amethyst blocks needed to flag a chunk that has no budding amethyst left.", 16, 4, 64, 1));
    public final NumberSetting scansPerTick = add(new NumberSetting("Scans per tick",
            "Chunks scanned per tick. Lower is lighter on performance.", 1, 1, 8, 1));
    public final BoolSetting notify = add(new BoolSetting("Chat notifications",
            "Print coordinates in chat when a new geode chunk is found.", true));

    public final BoolSetting beam = add(new BoolSetting("Beam",
            "Draw a glowing particle pillar above each flagged geode so you can spot it from far away.", true));
    public final NumberSetting beamHeight = add(new NumberSetting("Beam height",
            "How many blocks tall the pillar is.", 48, 16, 128, 8));
    public final NumberSetting beamRange = add(new NumberSetting("Beam range",
            "Only draw pillars for geodes within this many blocks of you.", 256, 64, 512, 32));

    private int beamTimer;

    private final Map<ChunkPos, Hit> hits = new HashMap<>();
    private final ArrayDeque<ChunkPos> queue = new ArrayDeque<>();

    public SusChunkFinder() {
        super("Sus Chunk Finder", "Finds chunks containing amethyst geodes.", Category.CHUNK_FINDING);
        ClientChunkEvents.CHUNK_LOAD.register((world, chunk) -> { if (isEnabled()) queue.add(chunk.getPos()); });
        ClientChunkEvents.CHUNK_UNLOAD.register((world, chunk) -> hits.remove(chunk.getPos()));
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> { hits.clear(); queue.clear(); });
    }

    public Map<ChunkPos, Hit> hits() { return hits; }

    @Override
    protected void onEnable(MinecraftClient mc) {
        hits.clear();
        queue.clear();
        if (mc.player == null) return;
        int r = mc.options.getClampedViewDistance();
        ChunkPos c = mc.player.getChunkPos();
        for (int dx = -r; dx <= r; dx++)
            for (int dz = -r; dz <= r; dz++) queue.add(new ChunkPos(c.x + dx, c.z + dz));
    }

    @Override
    protected void onDisable(MinecraftClient mc) {
        hits.clear();
        queue.clear();
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.world == null) return;
        if (beam.get() && ++beamTimer >= 8) {
            beamTimer = 0;
            spawnBeams(mc);
        }
        for (int i = 0; i < scansPerTick.getInt() && !queue.isEmpty(); i++) {
            ChunkPos pos = queue.poll();
            if (!(mc.world.getChunk(pos.x, pos.z, ChunkStatus.FULL, false) instanceof WorldChunk chunk)) continue;
            boolean had = hits.containsKey(pos);
            Hit hit = scan(chunk);
            if (hit == null) { hits.remove(pos); continue; }
            hits.put(pos, hit);
            if (!had && notify.get() && mc.player != null)
                mc.player.sendMessage(Text.literal("\u00a7d[Minion] \u00a7fGeode in chunk " + pos.x + ", " + pos.z
                        + " \u00a77(~" + hit.minX() + ", " + hit.minY() + ", " + hit.minZ() + ")"), false);
        }
    }

    /** Particle pillar: stable API, visible through terrain, but dotted rather than a solid beam. */
    private void spawnBeams(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) return;
        double range = beamRange.getDouble();
        int height = beamHeight.getInt();
        int topLimit = mc.world.getTopYInclusive();
        for (Hit h : hits.values()) {
            double cx = (h.minX() + h.maxX()) / 2.0, cz = (h.minZ() + h.maxZ()) / 2.0;
            double dx = cx - mc.player.getX(), dz = cz - mc.player.getZ();
            if (dx * dx + dz * dz > range * range) continue;
            double yTop = Math.min(h.maxY() + height, topLimit);
            for (double y = h.minY(); y <= yTop; y += 2.0)
                mc.world.addParticleClient(ParticleTypes.END_ROD, true, true, cx, y, cz, 0, 0, 0);
        }
    }

    private static boolean isAmethyst(BlockState s) {
        return s.isOf(Blocks.AMETHYST_BLOCK) || s.isOf(Blocks.BUDDING_AMETHYST)
                || s.isOf(Blocks.AMETHYST_CLUSTER) || s.isOf(Blocks.LARGE_AMETHYST_BUD)
                || s.isOf(Blocks.MEDIUM_AMETHYST_BUD) || s.isOf(Blocks.SMALL_AMETHYST_BUD);
    }

    private Hit scan(WorldChunk chunk) {
        ChunkSection[] sections = chunk.getSectionArray();
        int bottom = chunk.getBottomY();
        int sx = chunk.getPos().getStartX(), sz = chunk.getPos().getStartZ();
        int budding = 0, blocks = 0;
        int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE, maxZ = Integer.MIN_VALUE;

        for (int i = 0; i < sections.length; i++) {
            ChunkSection sec = sections[i];
            if (sec == null || sec.isEmpty() || !sec.hasAny(SusChunkFinder::isAmethyst)) continue;
            int baseY = bottom + i * 16;
            for (int x = 0; x < 16; x++)
                for (int y = 0; y < 16; y++)
                    for (int z = 0; z < 16; z++) {
                        BlockState st = sec.getBlockState(x, y, z);
                        if (!isAmethyst(st)) continue;
                        Block b = st.getBlock();
                        if (b == Blocks.BUDDING_AMETHYST) budding++;
                        if (b == Blocks.BUDDING_AMETHYST || b == Blocks.AMETHYST_BLOCK) blocks++;
                        int wx = sx + x, wy = baseY + y, wz = sz + z;
                        minX = Math.min(minX, wx); maxX = Math.max(maxX, wx);
                        minY = Math.min(minY, wy); maxY = Math.max(maxY, wy);
                        minZ = Math.min(minZ, wz); maxZ = Math.max(maxZ, wz);
                    }
        }
        if (budding == 0 && blocks < minBlocks.getInt()) return null;
        return new Hit(minX, minY, minZ, maxX + 1, maxY + 1, maxZ + 1, budding, blocks);
    }
}
