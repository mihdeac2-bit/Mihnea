package dev.minion.gui;

import dev.minion.config.ConfigManager;
import dev.minion.core.setting.BlockListSetting;
import dev.minion.modules.ClickGuiModule;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Searchable list of every block. Left-click toggles, right-click cycles the color of a selected block. */
public class BlockPickerScreen extends Screen {
    private static List<String> ALL;

    private final Screen parent;
    private final BlockListSetting setting;
    private String search = "";
    private boolean onlySelected;
    private float scroll, scrollTarget;
    private int px, pw, listTop, listBottom, rowH = 14;
    private List<String> shown = new ArrayList<>();

    public BlockPickerScreen(Screen parent, BlockListSetting setting) {
        super(Text.literal("Block picker"));
        this.parent = parent;
        this.setting = setting;
        if (ALL == null) {
            List<String> ids = new ArrayList<>();
            for (Identifier id : Registries.BLOCK.getIds()) {
                var b = Registries.BLOCK.get(id);
                if (b == Blocks.AIR || b == Blocks.CAVE_AIR || b == Blocks.VOID_AIR) continue;
                ids.add(id.toString());
            }
            ids.sort(Comparator.naturalOrder());
            ALL = ids;
        }
    }

    @Override public boolean shouldPause() { return false; }

    @Override
    public void close() {
        ConfigManager.save();
        MinecraftClient.getInstance().setScreen(parent);
    }

    private void refilter() {
        String q = search.toLowerCase(Locale.ROOT).trim();
        shown = new ArrayList<>();
        for (String id : ALL) {
            if (onlySelected && !setting.has(id)) continue;
            if (!q.isEmpty() && !id.toLowerCase(Locale.ROOT).contains(q)) continue;
            shown.add(id);
        }
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        ClickGuiModule g = ClickGuiModule.INSTANCE;
        int accent = g.accent.get();
        refilter();

        ctx.fill(0, 0, width, height, g.dim.getInt() << 24);
        pw = Math.min(320, width - 16);
        px = (width - pw) / 2;
        int top = 12, bottom = height - 12;
        ctx.fill(px - 6, top - 6, px + pw + 6, bottom + 6, (g.opacity.getInt() << 24) | 0x0E0E14);
        ctx.fill(px - 6, top - 6, px + pw + 6, top - 4, accent);

        ctx.drawTextWithShadow(textRenderer, "Block picker  (" + setting.get().size() + " selected)",
                px + 2, top + 3, accent);

        int sy = top + rowH + 4;
        int btnW = 90;
        ctx.fill(px, sy, px + pw - btnW - 4, sy + rowH + 2, 0xFF1A1A24);
        boolean empty = search.isEmpty();
        String txt = empty ? "Search blocks..." : search + ((System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
        ctx.drawTextWithShadow(textRenderer, txt, px + 6, sy + 4, empty ? 0xFF707080 : 0xFFFFFFFF);
        int bx = px + pw - btnW;
        ctx.fill(bx, sy, bx + btnW, sy + rowH + 2, onlySelected ? (accent & 0xFFFFFF) | 0x99000000 : 0xFF1A1A24);
        ctx.drawTextWithShadow(textRenderer, "Selected only", bx + 6, sy + 4, 0xFFFFFFFF);

        listTop = sy + rowH + 8;
        listBottom = bottom - rowH;
        int viewport = listBottom - listTop;
        float maxScroll = Math.max(0, shown.size() * rowH - viewport);
        scrollTarget = Math.max(0, Math.min(maxScroll, scrollTarget));
        scroll += (scrollTarget - scroll) * (g.animations.get() ? 0.3f : 1f);
        if (Math.abs(scrollTarget - scroll) < 0.5f) scroll = scrollTarget;

        ctx.enableScissor(px - 2, listTop, px + pw + 2, listBottom);
        int first = Math.max(0, (int) (scroll / rowH));
        for (int i = first; i < shown.size(); i++) {
            int y = listTop + i * rowH - Math.round(scroll);
            if (y > listBottom) break;
            String id = shown.get(i);
            boolean sel = setting.has(id);
            boolean hover = my >= listTop && my <= listBottom && mx >= px && mx < px + pw && my >= y && my < y + rowH;
            ctx.fill(px, y, px + pw, y + rowH - 1, hover ? 0xFF262632 : 0xFF1A1A24);
            ctx.fill(px + 3, y + 2, px + 3 + 9, y + rowH - 3, sel ? setting.get().get(id) : 0xFF33333F);
            String name = id.startsWith("minecraft:") ? id.substring(10) : id;
            ctx.drawTextWithShadow(textRenderer, name, px + 18, y + (rowH - 8) / 2, sel ? 0xFFFFFFFF : 0xFFA0A0B0);
        }
        ctx.disableScissor();

        ctx.fill(px, bottom - rowH + 2, px + pw, bottom, 0xFF12121A);
        ctx.drawTextWithShadow(textRenderer, "Left: add/remove  |  Right: change color  |  Esc: back",
                px + 6, bottom - rowH + 5, 0xFFA0A0B0);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y();
        int btn = click.button();
        int sy = 12 + rowH + 4;
        int btnW = 90;
        if (my >= sy && my < sy + rowH + 2 && mx >= px + pw - btnW && mx < px + pw) {
            onlySelected = !onlySelected;
            scrollTarget = 0;
            return true;
        }
        if (my >= listTop && my <= listBottom && mx >= px && mx < px + pw) {
            int idx = (int) ((my - listTop + scroll) / rowH);
            if (idx >= 0 && idx < shown.size()) {
                String id = shown.get(idx);
                if (btn == 1) setting.cycleColor(id, 1);
                else setting.toggle(id);
                return true;
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scrollTarget -= (float) (verticalAmount * rowH * 3);
        return true;
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        if (input.getKeycode() == GLFW.GLFW_KEY_BACKSPACE && !search.isEmpty()) {
            search = search.substring(0, search.length() - 1);
            scrollTarget = 0;
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public boolean charTyped(CharInput input) {
        if (input.isValidChar() && search.length() < 40) {
            search += input.asString();
            scrollTarget = 0;
            return true;
        }
        return super.charTyped(input);
    }
}
