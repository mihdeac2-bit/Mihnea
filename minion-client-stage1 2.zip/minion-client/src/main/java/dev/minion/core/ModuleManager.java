package dev.minion.core;

import dev.minion.MinionClient;
import dev.minion.render.Renderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public void register(Module m) { modules.add(m); }
    public List<Module> all() { return Collections.unmodifiableList(modules); }

    public List<Module> in(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : modules) if (m.category == c) out.add(m);
        out.sort((a, b) -> a.name.compareToIgnoreCase(b.name));
        return out;
    }

    public Module byName(String name) {
        for (Module m : modules) if (m.name.equals(name)) return m;
        return null;
    }

    public void tick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) return;
        if (mc.currentScreen == null) pollKeys(mc);
        for (Module m : modules) {
            if (!m.isToggleable() || !m.isEnabled()) continue;
            try {
                m.onTick(mc);
            } catch (Throwable t) {
                MinionClient.LOG.error("Module {} crashed and was disabled", m.name, t);
                m.setEnabled(false);
            }
        }
    }

    public void render(Renderer r) {
        for (Module m : modules) {
            if (!m.isToggleable() || !m.isEnabled()) continue;
            try {
                m.onRender(r);
            } catch (Throwable t) {
                MinionClient.LOG.error("Module {} failed while rendering and was disabled", m.name, t);
                m.setEnabled(false);
            }
        }
    }

    private void pollKeys(MinecraftClient mc) {
        long handle = mc.getWindow().getHandle();
        for (Module m : modules) {
            int k = m.getKey();
            if (k < 0 || !m.isToggleable()) { m.wasDown = false; continue; }
            boolean down = GLFW.glfwGetKey(handle, k) == GLFW.GLFW_PRESS;
            if (down && !m.wasDown) {
                m.setEnabled(!m.isEnabled());
                mc.player.sendMessage(Text.literal("\u00a7d[Minion] \u00a7f" + m.name
                        + (m.isEnabled() ? " \u00a7aON" : " \u00a7cOFF")), true);
            }
            m.wasDown = down;
        }
    }
}
