package dev.minion.core.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.util.LinkedHashMap;
import java.util.Map;

/** A set of block ids (e.g. "minecraft:diamond_ore"), each with its own ARGB highlight color. */
public class BlockListSetting extends Setting<Map<String, Integer>> {
    /** Bumped on every change so scanners know to rebuild. */
    public int version;

    public BlockListSetting(String name, String description, Map<String, Integer> def) {
        super(name, description, def);
        this.value = new LinkedHashMap<>(def);
    }

    public boolean has(String id) { return value.containsKey(id); }

    public void toggle(String id) {
        if (value.remove(id) == null) value.put(id, ColorSetting.PALETTE[value.size() % ColorSetting.PALETTE.length]);
        version++;
    }

    public void cycleColor(String id, int dir) {
        Integer cur = value.get(id);
        if (cur == null) return;
        int idx = -1;
        for (int i = 0; i < ColorSetting.PALETTE.length; i++) if (ColorSetting.PALETTE[i] == cur) idx = i;
        value.put(id, ColorSetting.PALETTE[Math.floorMod(idx + dir, ColorSetting.PALETTE.length)]);
        version++;
    }

    @Override
    public void reset() {
        value = new LinkedHashMap<>(def);
        version++;
    }

    @Override
    public JsonElement toJson() {
        JsonObject o = new JsonObject();
        for (Map.Entry<String, Integer> e : value.entrySet()) o.addProperty(e.getKey(), e.getValue());
        return o;
    }

    @Override
    public void fromJson(JsonElement e) {
        if (e == null || !e.isJsonObject()) throw new IllegalArgumentException("expected object");
        Map<String, Integer> parsed = new LinkedHashMap<>();
        for (Map.Entry<String, JsonElement> en : e.getAsJsonObject().entrySet()) {
            JsonElement v = en.getValue();
            if (!v.isJsonPrimitive() || !v.getAsJsonPrimitive().isNumber()) continue;
            parsed.put(en.getKey(), (int) v.getAsLong());
        }
        value = parsed;
        version++;
    }
}
