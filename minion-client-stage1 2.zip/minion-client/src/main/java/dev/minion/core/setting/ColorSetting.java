package dev.minion.core.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

/** ARGB color. Stage 1 UI cycles through a palette; the RGB/HSV picker comes with the rendering stage. */
public class ColorSetting extends Setting<Integer> {
    public static final int[] PALETTE = {
            0xFFFF69DC, 0xFF55FFFF, 0xFF55FF55, 0xFFFFFF55, 0xFFFF5555, 0xFFAA55FF, 0xFFFFFFFF
    };

    public ColorSetting(String name, String description, int argb) {
        super(name, description, argb);
    }

    public void cycle(int dir) {
        int idx = -1;
        for (int i = 0; i < PALETTE.length; i++) if (PALETTE[i] == value) idx = i;
        idx = Math.floorMod(idx + dir, PALETTE.length);
        value = PALETTE[idx];
    }

    @Override public JsonElement toJson() { return new JsonPrimitive(value); }

    @Override
    public void fromJson(JsonElement e) {
        if (e == null || !e.isJsonPrimitive() || !e.getAsJsonPrimitive().isNumber())
            throw new IllegalArgumentException("expected number");
        value = (int) e.getAsLong();
    }
}
