package dev.minion.core;

import dev.minion.MinionClient;
import dev.minion.core.setting.Setting;
import dev.minion.render.Renderer;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public abstract class Module {
    public final String name;
    public final String description;
    public final Category category;

    private final int defaultKey;
    private int key;
    private boolean enabled;
    private boolean toggleable = true;
    private final List<Setting<?>> settings = new ArrayList<>();

    /** Edge-detection state for the keybind poller. */
    public boolean wasDown;

    protected Module(String name, String description, Category category) {
        this(name, description, category, -1);
    }

    protected Module(String name, String description, Category category, int defaultKey) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.defaultKey = defaultKey;
        this.key = defaultKey;
    }

    protected <S extends Setting<?>> S add(S setting) {
        settings.add(setting);
        return setting;
    }

    /** For modules that only hold settings (no on/off). */
    protected void alwaysOn() {
        toggleable = false;
        enabled = true;
    }

    public List<Setting<?>> getSettings() { return Collections.unmodifiableList(settings); }
    public boolean isEnabled() { return enabled; }
    public boolean isToggleable() { return toggleable; }
    public int getKey() { return key; }
    public void setKey(int key) { this.key = key; }

    public void setEnabled(boolean on) {
        if (!toggleable || on == enabled) return;
        enabled = on;
        try {
            if (on) onEnable(MinecraftClient.getInstance());
            else onDisable(MinecraftClient.getInstance());
        } catch (Throwable t) {
            MinionClient.LOG.error("Module {} failed during {}", name, on ? "enable" : "disable", t);
            enabled = false;
        }
    }

    public void resetToDefaults() {
        for (Setting<?> s : settings) s.reset();
        key = defaultKey;
        if (toggleable) setEnabled(false);
    }

    protected void onEnable(MinecraftClient mc) {}
    protected void onDisable(MinecraftClient mc) {}
    public void onTick(MinecraftClient mc) {}

    /** Called every frame while enabled; queue world drawing on the shared renderer. */
    public void onRender(Renderer r) {}
}
